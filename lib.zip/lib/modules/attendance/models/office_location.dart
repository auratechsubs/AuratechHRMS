// class OfficeLocation {
//   final String id;
//   final String name;
//   final double latitude;
//   final double longitude;
//   final int radiusM; // default 50 (per office configurable)
//
//   OfficeLocation({
//     required this.id,
//     required this.name,
//     required this.latitude,
//     required this.longitude,
//     this.radiusM = 50,
//   });
// }
